In order to install the Scala kernel on a Windows machine you have to:

1) Make sure you have java.exe in your path (in cmd you type "java -version" and returns your java version)

2) Copy .coursier folder into %USERPROFILE% folder

3) Copy scala folder into your jupyter's kernels folder. It could be:
	C:\Python\share\jupyter\kernels
	C:\ProgramData\jupyter\kernels

4) Edit kernel.json that you have just copied (inside scala folder) changing the directory (line 8). As before, it could be:
	C:\\Python\\share\\jupyter\\kernels\\scala\\launcher.jar
	C:\\ProgramData\\jupyter\\kernels\\scala\\launcher.jar

5) Use this kernel from Jupyter notebook, running
  jupyter notebook
and selecting the "Scala" kernel.


Note: If you encounter some error with the kernel you can debug jupyter notebook adding --debug:
	jupyter notebook --debug

Jupyter Scala kernel Source: https://github.com/alexarchambault/jupyter-scala